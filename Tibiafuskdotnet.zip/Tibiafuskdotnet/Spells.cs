﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tibiafuskdotnet
{
    class Spells
    {/* Spells
string AvalancheRune = "adori mas frigo";
string Berserk = "exori";
string BloodRage = "utito tempo";
string BruiseBane = "exura infir ico";
string BrutalStrike = "exori ico";
string Buzz = "exori infir vis";
string CancelInvisibility = "exana ina";
string CancelMagicShield = "exana vita";
string Challenge = "exeta res";
string ChameleonRune = "adevo ina";
string Charge = "utani tempo hur";
string ChillOut = "exevo infir frigo hur";
string ChivalrousChallenge = "exeta amp res";
string ConjureArrow = "exevo con";
string ConjureExplosiveArrow = "exevo con flam";
string ConjureWandofDarkness = "exevo gran mort";
string ConvinceCreatureRune = "adeta sio";
string CreatureIllusion = "utevo res ina = ";
string CureBleeding = "exana kor";
string CureBurning = "exana flam";
string CureCurse = "exana mort";
string CureElectrification = "exana vis";
string CurePoison = "exana pox";
string CurePoisonRune = "adana pox";
string Curse = "utori mort";
string DeathStrike = "exori mort";
string DestroyFieldRune = "adito grav";
string DisintegrateRune = "adito tera";
string DivineCaldera = "exevo mas san";
string DivineDazzle = "exana amp res";
string DivineHealing = "exura san";
string DivineMissile = "exori san";
string Electrify = "utori vis";
string EnchantParty = "utori mas sio";
string EnchantSpear = "exeta con";
string EnergyBeam = "exevo vis lux";
string EnergyBombRune = "adevo mas vis";
string EnergyFieldRune = "adevo grav vis";
string EnergyStrike = "exori vis";
string EnergyWallRune = "adevo mas grav vis";
string EnergyWave = "exevo vis hur";
string Envenom = "utori pox";
string EternalWinter = "exevo gran mas frigo";
string EtherealSpear = "exori con";
string ExplosionRune = "adevo mas hur";
string ExposeWeakness = "exori moe";
string FierceBerserk = "exori gran";
string FindPerson = "exiva";
string FireBombRune = "adevo mas flam";
string FireFieldRune = "adevo grav flam";
string FireWallRune = "adevo mas grav flam";
string FireWave = "exevo flam hur";
string FireballRune = "adori flam";
string FlameStrike = "exori flam";
string Food = "exevo pan";
string GreatEnergyBeam = "exevo gran vis lux";
string GreatFireballRune = "adori mas flam";
string UltimateHealing = "exura vita";
*/

    }
}
