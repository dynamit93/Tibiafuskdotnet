namespace Tibia.Addresses
{
    public class Hotkey
    {
        public static uint SendAutomaticallyStart = 0x7BCD08;// 8.62
        public static uint SendAutomaticallyStep = 0x1;

        public static uint TextStart = 0x7BCD30;// 8.62
        public static uint TextStep = 0x100;

        public static uint ObjectStart = 0x7BCC78;// 8.62
        public static uint ObjectStep = 0x4;

        public static uint ObjectUseTypeStart = 0x7BCB58;// 8.62
        public static uint ObjectUseTypeStep = 0x4;

        public static uint MaxHotkeys = 36;
    }
}
