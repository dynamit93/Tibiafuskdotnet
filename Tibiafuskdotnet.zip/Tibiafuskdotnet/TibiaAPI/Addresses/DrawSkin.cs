﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tibia.Addresses
{
    public class DrawSkin
    {
        public static uint DrawSkinFunc = 0x4B57A0;//8.62
    }
}
