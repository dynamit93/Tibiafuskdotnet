﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tibia.Addresses
{
    public class DrawItem
    {
        public static uint DrawItemFunc = 0x4B1B30; //8.62
    }
}
