﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tibiafuskdotnet.BL
{
   public class Cheat
    {
       
        public Int32 SpellHiHealth { get; set; }
        public Int32 SpellLoHealth { get; set; }
        public Int32 HpPotionHealth { get; set; }
        public Int32 UhRuneHealth { get; set; }
        public Int32 TargetingHpMin { get; set; }
                
        public Int32 TargetingHpMax { get; set; }
        public Int32 SpellHiMana { get; set; }
        public Int32 SpellLoMana { get; set; }
        public string ManaPotiontext { get; set; }
        public string SpellHitext { get; set; }
        public string SpellLotext { get; set; }
        public string UhRunetext { get; set; }
        public string HpPotiontext { get; set; }



        


    }
}
