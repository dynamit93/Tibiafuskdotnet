namespace Tibia.Addresses
{
    public class Hotkey
    {
        public static uint SendAutomaticallyStart;
        public static uint SendAutomaticallyStep;

        public static uint TextStart;
        public static uint TextStep;

        public static uint ObjectStart;
        public static uint ObjectStep;

        public static uint ObjectUseTypeStart;
        public static uint ObjectUseTypeStep;

        public static uint MaxHotkeys;
    }
}
